package es.uma.taw.proyectotaw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoTawApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProyectoTawApplication.class, args);
    }

}
