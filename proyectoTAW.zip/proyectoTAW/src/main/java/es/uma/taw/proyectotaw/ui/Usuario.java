package es.uma.taw.proyectotaw.ui;

import lombok.Data;

@Data
public class Usuario {
    protected String correo;
    protected String password;
}
