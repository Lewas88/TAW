package es.uma.taw.proyectotaw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoTawApplicationTests {

    @Test
    void contextLoads() {
    }

}
